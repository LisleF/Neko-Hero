require 'states/Game/mouse'
require 'states/Game/bullet'

moveTime = 0-- timing of hamsters' movements
hamster_remaining = 0
score = 0 
launchTime = 0
function load()
	Entities = {}--all creatures of the universe 
	Bullets = {}-- all laser shots in the universe
	player = Mouse.create('player', 100, 600, 32, 32)
	table.insert(Entities, player)
	normalh_image = love.graphics.newImage("Draws/normal_hamster_ship.png")
	japah_image = love.graphics.newImage("Draws/japa_hamster_ship.png")
	tuffh_image = love.graphics.newImage("Draws/tuff_hamster_ship.png")
	kingh_image = love.graphics.newImage("Draws/king_hamster_ship.png")
	image_hero = love.graphics.newImage("Draws/centralgodneko.png")
	image_righthero = love.graphics.newImage('Draws/right_godneko.png')
	image_lefthero = love.graphics.newImage('Draws/left_godneko.png')
	background = love.graphics.newImage("space-fase-1.jpg")
	nya_nya_song = love.audio.newSource("Audios/Pikachu-Nya_Nya_Song.mp3", "stream")
	nya_nya_song:play()
	font = love.graphics.newFont("Fontes/PLAST___.TTF", 30)
	love.graphics.setFont(font)
	level = 1
	drawLevel1 = true
	drawLevel2 = true
	drawLevel3 = true
	drawLevel4 = true
	drawLevel5 = true
	love.window.setMode(800, 600, {resizable=true, vsync=false, minwidth=400, minheight=300})
    love.window.maximize()
end

function love.draw()
	love.graphics.setColor(255, 255, 255, 255)--seta  a cor
	love.graphics.draw(background, 0, 0, 0, 0.75, 0.75)--materializing universe background
	for i,v in pairs(Entities) do--desenha os seres
		v:draw()
	end
	for i, v in pairs(Bullets) do--desenha as balas
		v:draw()
	end
	love.graphics.print("Score = " .. score, 0, 0, 0, 1, 1)
end

function readKeys(dt)
	local speed = player.speed
	if love.keyboard.isDown('a') then
		player.dx = -speed*dt
	end
	if love.keyboard.isDown('d') then
		player.dx = speed*dt
	end

	if love.mouse.isDown(1) then
		player:fire(dt)
	end
end

function love.update(dt)
	moveTime = moveTime + dt
	launchTime = launchTime + dt
	for i,v in pairs(Entities) do
		v:update(dt)
		if v.name ~= 'player' then
			v:enemyShoot(dt)
		end
	end
	for i,v in pairs(Bullets) do
		v:update(dt)
	end
	if moveTime >= 1 then
		for i,v in pairs(Entities) do
			if v.name ~= 'player' then
				v:enemyMove()
				moveTime = 0
			end
		end
	end
	for i,v in pairs(Entities) do-- gets player's position
		if v.name == 'player' then
			playerX, playerY = v.x, v.y
		end
	end
	for i, v in pairs(Entities) do
		if v.name == 'japa-hamster' and launchTime >= 2 then
			if v.y < playerY then
				v:setDestiny(playerX, playerY)
				launchTime = 0
			end
		end
	end
	if level == 1 and drawLevel1 then-- spawning hamsters in fase 1
		for i = 1,7 do 
		    table.insert(Entities, Mouse.create('normal-hamster', 30 + (150*i), 100, 82, 76.4))-- creating normal hamsters
	    end
	    for i = 1,8 do
		    table.insert(Entities, Mouse.create('normal-hamster', -50 + (150*i), 20, 82, 76.4)) -- creating normal hamsters
	    end
	    for i = 1,7 do 
		    table.insert(Entities, Mouse.create('normal-hamster', 30 + (150*i), -60, 82, 76.4))-- creating normal hamsters
	    end
	    hamster_remaining = 22
	    drawLevel1 = false
	end

	if level == 2 and drawLevel2 then -- spawning hamsters in fase 2
		for i = 1,7 do 
		    table.insert(Entities, Mouse.create('japa-hamster', 30 + (150*i), 100, 82, 76.4))-- creating normal hamsters
	    end
	    for i = 1,8 do
		    table.insert(Entities, Mouse.create('normal-hamster', -50 + (150*i), 20, 82, 76.4)) -- creating normal hamsters
	    end
	    for i = 1,7 do 
		    table.insert(Entities, Mouse.create('normal-hamster', 30 + (150*i), -60, 82, 76.4))-- creating normal hamsters
	    end															
	    hamster_remaining = 22
	    drawLevel2 = false
	end
	if level == 3 and drawLevel3 then-- spawning hamsters in fase 3
		for i = 1,8 do
		    table.insert(Entities, Mouse.create('normal-hamster', -50 + (150*i), 100, 82, 76.4)) -- creating normal hamsters
	    end
		for i = 1,7 do 
		    table.insert(Entities, Mouse.create('japa-hamster', 30 + (150*i), 20, 82, 76.4))-- creating normal hamsters
	    end
	    for i = 1,8 do
		    table.insert(Entities, Mouse.create('normal-hamster', -50 + (150*i), -60, 82, 76.4)) -- creating normal hamsters
	    end
	    for i = 1,7 do 
		    table.insert(Entities, Mouse.create('normal-hamster', 30 + (150*i), -140, 82, 76.4))-- creating normal hamsters
	    end
	    hamster_remaining = 30
	    drawLevel3 = false
	end

	if level == 4 and drawLevel4 then-- spawning hamsters in fase 4
		for i = 1,7 do 
		    table.insert(Entities, Mouse.create('japa-hamster', 30 + (150*i), 100, 82, 76.4))-- creating normal hamsters
	    end
	    for i = 1,8 do
		    table.insert(Entities, Mouse.create('normal-hamster', -50 + (150*i), 20, 82, 76.4)) -- creating normal hamsters
	    end
	    for i = 1,8 do
		    table.insert(Entities, Mouse.create('normal-hamster', -50 + (150*i), -60, 82, 76.4)) -- creating normal hamsters
	    end
	    for i = 1,7 do 
		    table.insert(Entities, Mouse.create('normal-hamster', 30 + (150*i), -140, 82, 76.4))-- creating normal hamsters
	    end
	    for i = 1,6 do 
		    table.insert(Entities, Mouse.create('tuff-hamster', 80 + (150*i), -220, 82, 76.4))-- creating normal hamsters
	    end
	    hamster_remaining = 36
	    drawLevel4 = false
	end

	if level == 5 and drawLevel5 then-- spawning hamsters in fase 5
		for i = 1,7 do 
		    table.insert(Entities, Mouse.create('japa-hamster', 30 + (150*i), 100, 82, 76.4))-- creating normal hamsters
	    end
	    for i = 1,8 do
		    table.insert(Entities, Mouse.create('normal-hamster', -50 + (150*i), 20, 82, 76.4)) -- creating normal hamsters
	    end
	    for i = 1,8 do
		    table.insert(Entities, Mouse.create('normal-hamster', -50 + (150*i), -60, 82, 76.4)) -- creating normal hamsters
	    end
	    for i = 1,7 do 
		    table.insert(Entities, Mouse.create('normal-hamster', 30 + (150*i), -140, 82, 76.4))-- creating normal hamsters
	    end
	    for i = 1,5 do 
		    table.insert(Entities, Mouse.create('normal-hamster', 80 + (150*i), -220, 82, 76.4))-- creating normal hamsters
	    end
	    for i = 1,6 do 
		    table.insert(Entities, Mouse.create('tuff-hamster', 80 + (150*i), -300, 82, 76.4))-- creating normal hamsters
	    end
	    for i = 1,1 do 
		    table.insert(Entities, Mouse.create('king-hamster', 600, -380, 82, 76.4))-- creating normal hamsters
	    end
	    hamster_remaining = 42
	    drawLevel5 = false
	end
    if hamster_remaining <= 0 and level == 5 then
	    loadState("Win")
	end
	if hamster_remaining <= 0 then
		if level == 4 then
			level = 5
		elseif level == 3 then
			level = 4
		elseif level == 2 then
			level = 3
		elseif level == 1 then
			level = 2
		end
	end
	readKeys(dt)
end


