Mouse = {}
Mouse.__index = Mouse

local deltatime = 0
local playerDeltaTime = 0
japaDT, japaCD = 0, 10
cat_laser = love.audio.newSource("Audios/sci_fi_lazer_shot.wav", "static")

function Mouse.create(name, x, y, w, h)
	local m = {}
	setmetatable(m, Mouse)
	m.name = name
	m.x, m.y, m.w, m.h = x, y, w, h -- posições
	if m.name == 'player' or 'normal-hamster' or 'japa-hamster' then
		m.health = 1
	elseif m.name == 'tuff-hamster' then
		m.health = 3
	elseif m.name == 'king-hamster' then
		m.health = 5
	end
	m.speed = 200
	if m.name == 'player' then
		m.atkspd= 0.8
	elseif name ~= 'player' then
		m.atkspd = 8
	end
	if name == 'japa-hamster' then
		m.velocity = 1
	end
	m.dx = 0 -- velocidade ("aceleração") x
	m.dy = 0 -- velocidade ("aceleração") y
	return m
end

function Mouse:draw()
	love.graphics.setColor(255,255,255,255)
	if self.name == 'normal-hamster' then
		love.graphics.draw(normalh_image, self.x, self.y, 0, 0.35, 0.35)
	elseif self.name == 'player' then
		love.graphics.draw(image_hero, self.x, self.y, 0, 0.75, 0.75)
	elseif self.name == 'japa-hamster' then
		love.graphics.draw(japah_image, self.x, self.y, 0, 0.35, 0.35)
	elseif self.name == 'tuff-hamster' then
		love.graphics.draw(tuffh_image, self.x, self.y, 0, 0.35, 0.35)
	elseif self.name == 'king-hamster' then
		love.graphics.draw(kingh_image, self.x, self.y, 0, 0.35, 0.35)
	end
end

function Mouse:update(dt)
	if self.name == 'player' then
		for i,v in pairs(Entities) do
			if v.name ~= 'player' then
				if self:checkCollision(self.x, self.y, self.w, self.h, v.x, v.y, v.w, v.h) then
					v:destroy()
					loadState("Lose")
				end
			end
		end
	end
	if self.name == 'player' then
		self.x = self.x + self.dx
		self.y = self.y + self.dy
		self.dx, self.dy = 0, 0
	elseif self.name == 'japa-hamster' then
		self.x = self.x + self.dx
		self.y = self.y + self.dy 
	end
	if self.y >= love.graphics.getHeight() then
	   if self.name ~= "player" then
		  self:destroy()
		end
	end
end

function Mouse:fire(dt)--
	playerDeltaTime = playerDeltaTime + dt
	if playerDeltaTime > self.atkspd then
	   bullet = Bullet.create(self.x + 82/2, self.y, self.name)
	   table.insert(Bullets, bullet)
	   cat_laser:play()
	   playerDeltaTime = 0
	end
end

function Mouse:enemyShoot(dt)-- hamsters' laser shots
	for i,v in pairs(Entities) do
		if v.name == 'player' then
			playerX = v.x
			playerY = v.y
		end
	end
	deltatime = deltatime + dt
	if deltatime > self.atkspd then
		bullet = Bullet.create(self.x + 82/2, self.y, self.name)
		bullet:setDestiny(playerX, playerY)
	    table.insert(Bullets, bullet)
	    deltatime = 0
	end
end

function Mouse:destroy()-- supose to kill hamsters
	for i = #Entities, 1, -1 do
		if Entities[i] == self then
			table.remove(Entities, i)
			hamster_remaining = hamster_remaining - 1
		end
	end
end

function Mouse:checkBoundary() -- window's limits
	if self.x < 0 then
		self.x = self.x
	end

	if self.x > love.graphics.getWidth() then
		self.x = self.x
	end
	if self.y > love.graphics.getHeight() then
		self:destroy()

	end
end

function Mouse:enemyMove()
	self.y = self.y + 20

end

function Mouse:checkCollision(x1, y1, w1, h1, x2, y2, w2, h2) -- colision between 2 squares
	return x1 < x2+w2 and 
	x2 < x1+w1 and
	y1 < y2+h2 and
	y2 < y1+h1
end

function Mouse:setDestiny(x, y) --set japa-hamsters' direction
	local angle = math.atan2((y-self.y), (x-self.x)) 
	self.dx = self.velocity*math.cos(angle)
	self.dy = self.velocity*math.sin(angle)+1
end