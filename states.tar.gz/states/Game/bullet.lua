Bullet = {}
Bullet.__index = Bullet

function Bullet.create(x, y, creator)
	local b = {}
	setmetatable(b, Bullet)
	b.x = x
	b.y = y
	b.creator = creator
	b.dx, b.dy = 0, 0
	if creator =="player" then
		b.velocity = 250
	elseif creator ~= "player" then
		b.velocity = 125
	end
	return b
end

function Bullet:draw()
	love.graphics.setColor(255,0,0,255)
	love.graphics.rectangle("fill", self.x, self.y, 6, 12)
end

function Bullet:update(dt)
	if self.creator ==  "player" then
		self.y = self.y -10
	elseif self.creator ~= "player" then
		self.x = self.x + (self.dx*dt)
	    self.y = self.y + (self.dy*dt)
	end
	for i,v in pairs(Entities) do
		if v.name =='player' and self.creator ~= "player" then
			if insideBox(self.x, self.y, v.x, v.y, v.w, v.h) then
				v.health = v.health - 1				
				if v.health <= 0 then
					loadState("Lose")
				end
			end
		elseif	v.name ~='player' and self.creator == "player" then
			if insideBox(self.x, self.y, v.x, v.y, v.w, v.h) then 
				self:destroy()
				v.health = v.health - 1
				if v.health <= 0 then
					v:destroy()
					if v.name == "normal-hamster" then
						score = score + 100
					elseif v.name == "japa-hamster" then
						score = score + 200
					elseif v.name == "tuff-hamster" then
						score = score + 500
					elseif v.name == "king-hamster" then
						score = score + 1000
					end
				end
			end
		end
	end
	self:checkBoundary()
end

function Bullet:destroy()--killing bullets
	for i = #Bullets, 1, -1 do
		if Bullets[i] == self then
			table.remove(Bullets, i)
		end
	end
end

function Bullet:checkBoundary()
	if self.x <= 20 then
		self:destroy()
	end
	if self.y <= 20 then
		self:destroy()
	end
	if self.x >= love.graphics.getWidth() then
		self:destroy()
	end
	if self.y >= love.graphics.getHeight() then
		self:destroy()
	end
end

function insideBox(px, py, x, y, wx, wy)--checking 
	if px > x and px < x + wx then
		if py > y and py < y + wy then
			return true
		end
	end
	return false
end

function Bullet:setDestiny(x, y) 
	local angle = math.atan2((y-self.y), (x-self.x)) -- teorema fundamental das derivadas
	self.dx = self.velocity*math.cos(angle)
	self.dy = self.velocity*math.sin(angle)
end