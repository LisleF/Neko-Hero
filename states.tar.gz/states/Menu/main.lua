function load()
	love.graphics.setBackgroundColor(255, 255, 255)
	name = love.graphics.newImage("Draws/name_game.png")
	start = love.graphics.newImage("Draws/start_button.png")
	cat = love.graphics.newImage("Draws/cat_planet.png")
	hamster = love.graphics.newImage("Draws/hamster_planet.png")
	love.window.setMode(800, 600, {resizable=true, vsync=false, minwidth=400, minheight=300})
	love.window.maximize()
end


function love.draw()
	love.graphics.setColor(255, 255, 255, 255)
	love.graphics.draw(name, 300, 100, 0, 1, 1)
	love.graphics.draw(start, 550, 300, 0, 1.2, 1.2)
	love.graphics.draw(cat, 800, 400, 0, 1, 1)
	love.graphics.draw(hamster, 300, 400, 0, 1, 1)
end

function love.mousepressed(x, y, button)
	if insideBox(x, y, 550, 300, 180, 79.2) then
		loadState("Game")
	end
	
end

function insideBox(px, py, x, y, wx, wy)
	if px > x and px < x + wx then
		if py > y and py < y + wy then
			return true
		end
	end
	return false
end
