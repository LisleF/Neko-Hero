function load()
	love.graphics.setBackgroundColor(71, 67, 130, 255)
	win_button = love.graphics.newImage("Draws/win_button.png")
	star_1 = love.graphics.newImage("Draws/star_1.png")
	star_2 = love.graphics.newImage("Draws/star_2.png")
	win_cat = love.graphics.newImage("Draws/win_cat.png")
	nya_nya_song:pause()
	love.window.setMode(800, 600, {resizable=true, vsync=false, minwidth=400, minheight=300})
	love.window.maximize()
end

function love.draw()
	love.graphics.setColor(255, 255, 255, 255)
	love.graphics.draw(win_button, 490, 10, 0, 0.6, 0.6)
	love.graphics.draw(win_cat, 450, 260, 0, 0.7, 0.7)
	love.graphics.draw(star_1, 420, 160, 0, 0.6, 0.6)
	love.graphics.draw(star_2, 420, 600, 0, 0.6, 0.6)
	love.graphics.print("Score:" .. score)
end