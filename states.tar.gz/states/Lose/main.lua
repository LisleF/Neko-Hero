function load()
	lose_screen = love.graphics.newImage("Draws/Lose_screen.png")
	nya_nya_song:pause()
	love.window.setMode(800, 600, {resizable=true, vsync=false, minwidth=400, minheight=300})
	love.window.maximize()
end

function love.draw()
	love.graphics.setColor(255, 255, 255, 255)
	love.graphics.draw(lose_screen, 0, 0, 0, 1, 1)
	love.graphics.setColor(255, 0, 0, 255)
	love.graphics.print("Score:".. score, 500, 600)
end